package com.in28minutes.springboot.microservice.eureka.naming.server.springbootmicroserviceeurekanamingserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMicroserviceEurekaNamingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
